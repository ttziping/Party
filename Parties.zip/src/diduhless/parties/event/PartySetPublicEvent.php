<?php


namespace diduhless\parties\event;


class PartySetPublicEvent extends PartyEvent {

}