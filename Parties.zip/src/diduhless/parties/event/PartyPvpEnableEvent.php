<?php


namespace diduhless\parties\event;


class PartyPvpEnableEvent extends PartyEvent {

}