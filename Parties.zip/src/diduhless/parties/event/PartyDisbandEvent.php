<?php


namespace diduhless\parties\event;


class PartyDisbandEvent extends PartyEvent {

}