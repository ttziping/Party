<?php


namespace diduhless\parties\event;


class PartyCreateEvent extends PartyEvent {

}