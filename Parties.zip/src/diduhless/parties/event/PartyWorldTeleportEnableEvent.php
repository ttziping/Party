<?php


namespace diduhless\parties\event;


class PartyWorldTeleportEnableEvent extends PartyEvent {

}