<?php


namespace diduhless\parties\event;


class PartyJoinEvent extends PartyEvent {

}