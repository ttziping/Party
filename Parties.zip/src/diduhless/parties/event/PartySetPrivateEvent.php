<?php


namespace diduhless\parties\event;


class PartySetPrivateEvent extends PartyEvent {

}