<?php


namespace diduhless\parties\event;


class PartyWorldTeleportDisableEvent extends PartyEvent {

}