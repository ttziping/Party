<?php


namespace diduhless\parties\event;


class PartyPvpDisableEvent extends PartyEvent {

}