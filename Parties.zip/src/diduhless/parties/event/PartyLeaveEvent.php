<?php


namespace diduhless\parties\event;


class PartyLeaveEvent extends PartyEvent {

}